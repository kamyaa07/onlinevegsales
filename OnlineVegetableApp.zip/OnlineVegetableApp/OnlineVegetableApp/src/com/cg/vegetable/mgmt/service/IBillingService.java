package com.cg.vegetable.mgmt.service;

public interface IBillingService {

}
