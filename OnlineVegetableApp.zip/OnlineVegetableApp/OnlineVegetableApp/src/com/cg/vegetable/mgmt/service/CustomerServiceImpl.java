package com.cg.vegetable.mgmt.service;

import java.util.List;

import com.cg.vegetable.mgmt.entities.Customer;
import com.cg.vegetable.mgmt.repository.CustomerRepositoryImpl;
public class CustomerServiceImpl implements ICustomerService
{
	CustomerRepositoryImpl customerRepository;


@Override
public Customer addCustomer(Customer customer) {
	return customerRepository.addCustomer(customer);
}

@Override
public Customer updateCustomer(Customer customer) {
	return customerRepository.updateCustomer(customer);
}

@Override
public Customer removeCustomer(Customer customer) {
	return customerRepository.removeCustomer(customer);
}

@Override
public Customer viewCustomer(Customer customer) {
	return customerRepository.viewCustomer(customer);
}

@Override
public List<Customer> viewAllCustomer(String location) {
	return customerRepository.viewAllCustomer(location);

}
}
