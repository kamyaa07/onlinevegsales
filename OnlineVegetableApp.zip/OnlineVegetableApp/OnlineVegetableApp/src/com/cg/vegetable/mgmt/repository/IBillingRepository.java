package com.cg.vegetable.mgmt.repository;

public interface IBillingRepository {

}
