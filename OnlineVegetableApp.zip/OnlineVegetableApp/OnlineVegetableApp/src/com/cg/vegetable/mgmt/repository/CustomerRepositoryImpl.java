package com.cg.vegetable.mgmt.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import com.cg.vegetable.mgmt.entities.Customer;

public class CustomerRepositoryImpl implements ICustomerRepository{

	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	
	public CustomerImpl() {
		entityManagerFactory = JPAUtil.getEntityManagerFactory();
		entityManager = entityManagerFactory.createEntityManager();
	}


	@Override
	public Customer addCustomer(Customer customer) {
		beginTransaction();
		Customer entity = new Customer();
		entity.setName(customer.getName());
		entity.setCustomerId(customer.getCustomerId());
		entityManager.persist(entity);
		commitTransaction();

	}

	@Override
	public Customer removeCustomer(Customer customer) {

		Customer entity = entityManager.find(Customer.class, customer.getCustomerId());
		if(entity!=null)		
			entityManager.remove(entity);
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		Customer entity = entityManager.find(Customer.class, customer.getCustomerId());
		if(entity!=null) {
			beginTransaction();
			entity.setName(customer.getName());
			commitTransaction();
		}
	}
	
	@Override
	public Customer viewCustomer(Customer customer) {
		
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
}
